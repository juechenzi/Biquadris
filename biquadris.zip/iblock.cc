#include "iblock.h"

Iblock::Iblock(std::string type,int n) {
	this->level = n;
	this->type = type;
	this->location = Pos{0,0};
	this->relative.clear();
	this->from = nullptr;
	this->left_over = 4;
	this->relative.push_back(Pos{0,0});
	this->relative.push_back(Pos{1,0});
	this->relative.push_back(Pos{2,0});
	this->relative.push_back(Pos{3,0});
}	

void Iblock::clockwise() {
	if (this->relative[1].x == 0) {
		this->relative.clear();
		this->relative.push_back(Pos{0,0});
		this->relative.push_back(Pos{1,0});
		this->relative.push_back(Pos{2,0});
		this->relative.push_back(Pos{3,0});
	} else {
		this->relative.clear();
		this->relative.push_back(Pos{0,0});
		this->relative.push_back(Pos{0,1});
		this->relative.push_back(Pos{0,2});
		this->relative.push_back(Pos{0,3});
	}
}

void Iblock::counterclockwise() {
	this->clockwise();
}
