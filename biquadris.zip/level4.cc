#include "level4.h"

std::shared_ptr<Block> Level4::get_block(int b) {
	if(b < 0){
		srand(time(0));
	} else {
		srand(b);
	}
	int a = rand() % 9;
	std::shared_ptr<Block> tmp = nullptr;
	if (a == 0 || a == 6) {
		tmp = std::shared_ptr<Block> (new ZSblock{"Z",4});
	} else if (a == 7 || a == 8) {
		tmp = std::shared_ptr<Block> (new ZSblock{"S",4});
	} else if (a == 1) {
		tmp =  std::shared_ptr<Block> (new JTLblock("J",4));
	} else if (a == 2) { 
		tmp = std::shared_ptr<Block> (new JTLblock("T",4));
	} else if (a == 3) {
		tmp = std::shared_ptr<Block> (new JTLblock("L",4));
	} else if (a == 4) {
		tmp =  std::shared_ptr<Block> (new Iblock("I",4));
	} else {
		tmp =  std::shared_ptr<Block> (new Oblock("O",4));
	}
	return tmp;
}

