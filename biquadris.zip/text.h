#ifndef TEXT_H
#define TEXT_H
#include "observer.h"

class Text: public Observer{
public: 
	Text(std::shared_ptr<Player> ply1,std::shared_ptr<Player> ply2);
//	void blind(int a) override;
	void print() override;
};

#endif
