#include "rblock.h"
#include <ctime>
Rblock::Rblock(int a){
//	std::cout<<"rblock is called"<<std::endl;
	this->level = a;
	this->type = "R";
	this->location = Pos{0,0};
	this->relative.clear();
	this->from = nullptr;
	this->left_over = 4;
	srand(time(0));
	while(true){
		std::cout<<relative.size()<<std::endl;
		if(relative.size() == 4) break;
		int n = rand()%6;
		Pos tmp;
		if(n ==0){
			tmp = Pos{0,0};
		} else if(n ==1){
			tmp = Pos{0,1};
		} else if(n ==2){
			tmp = Pos{1,1};
		} else if(n ==3){
			tmp = Pos{1,0};
		} else if(n ==4){
			tmp = Pos{2,0};
		} else if(n ==5){
			tmp = Pos{2,1};
		}
		if(relative.size() == 0){
			relative.emplace_back(tmp);
		}
		for(auto& b : relative){
			if(b.x == tmp.x && b.y == tmp.y){
				break;
			}
			if(b.x == relative.back().x && b.y == relative.back().y){
				relative.emplace_back(tmp);
			}
		}
	}
//	std::cout<<"r block is generated"<<std::endl;
}

void Rblock::clockwise() {
	bool cond = false;
	for(auto &a: relative){
		a = Pos{a.y,a.x};
	}
	for(auto &a: relative){
		if(a.y == 2){
			cond = true;
			break;
		}
	} 
	for(auto &a: relative){
		if(cond){
			a = Pos{a.x,2-a.y};
		} else {
			a = Pos{a.x,1-a.y};
		}
	}

}

void Rblock::counterclockwise() { 
	bool cond = false;
	for(auto &a: relative){
		a = Pos{a.y,a.x};
	}
	for(auto &a: relative){
		if(a.x == 2){
			cond = true;
			break;
		}
	} 
	for(auto &a: relative){
		if(cond){
			a = Pos{2-a.x,a.y};
		} else {
			a = Pos{1-a.x,a.y};
		}
	}
}



