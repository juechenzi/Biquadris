#include "graph.h"

Graph::Graph(std::shared_ptr<Player> ply1,std::shared_ptr<Player> ply2){
	this->pl1=ply1;
	this->pl2=ply2;
	this->size= 20;
	win.fillRectangle(0,0,500,500,Xwindow::Magenta);
//	win.fillRectangle(11*20,0,60,500,Xwindow::White);

}


void Graph::print(){
//	std::cout<<"Pos1"<<std::endl;
	win.fillRectangle(0,0,500,500,Xwindow::Magenta);
	std::string tmp1 = "Level:  ";
	std::string tmp2;
	tmp2 = tmp1 + std::to_string(pl1->get_level());
	tmp2.resize(31,' ');
	tmp2 += tmp1;
	tmp2 += std::to_string(pl2->get_level());
	tmp2.resize(45,' ');
	win.drawBigString(0,22,tmp2,Xwindow::Black);
	tmp1 = "Score:  ";
	tmp2 = tmp1 + std::to_string(pl1->get_score());
	tmp2.resize(30,' ');
	tmp2 += tmp1;
	tmp2 += std::to_string(pl2->get_score());
	tmp2.resize(45,' ');
	win.drawBigString(0,47,tmp2,Xwindow::Black);
	tmp2 = "";
	tmp2.resize(100,'-');
	win.drawString(0,60,tmp2,Xwindow::Black);
//	std::cout<<"Pos2"<<std::endl;
	std::vector<std::string> set1 = pl1->print();
	std::vector<std::string> set2 = pl2->print();
	for(int a = 0; a < set1.size();++a){
		for(int b =0; b < 11;++b){
			if(set1[a][b] != ' ' && set1[a][b] != '-'){
				win.fillRectangle(b*20,480 - a*20,20,20,Xwindow::Black);
				if(set1[a][b] == '*'){
					win.fillRectangle(b*20+1,480 - a*20 + 1,18,18,Xwindow::Green);
				} else if(set1[a][b] == 'O'){
					win.fillRectangle(b*20+1,480 - a*20 + 1,18,18,Xwindow::DarkGreen);
				} else if(set1[a][b] == 'S'){
					win.fillRectangle(b*20+1,480 - a*20 + 1,18,18,Xwindow::Red);
				} else if(set1[a][b] == 'J'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::Blue);
				} else if(set1[a][b] == 'Z'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::Yellow);
				} else if(set1[a][b] == 'L'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::Cyan);
				} else if(set1[a][b] == 'T'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::Brown);
				} else if(set1[a][b] == 'I'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::Orange);
				} else if(set1[a][b] == 'R'){
					win.fillRectangle( b*20+1,480 - a*20+ 1,18,18,Xwindow::White);
				}
			}
			if(set2[a][b] != ' ' && set1[a][b] != '-'){
					win.fillRectangle(280+b*20,480 - a*20,20,20,Xwindow::Black);
				if(set2[a][b] == '*'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Green);
				} else if(set2[a][b] == 'O'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::DarkGreen);
				} else if(set2[a][b] == 'S'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Red);
				} else if(set2[a][b] == 'J'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Blue);
				} else if(set2[a][b] == 'Z'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Yellow);
				} else if(set2[a][b] == 'L'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Cyan);
				} else if(set2[a][b] == 'T'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Brown);
				} else if(set2[a][b] == 'I'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::Orange);
				} else if(set2[a][b] == 'R'){
					win.fillRectangle(281+b*20,481 - a*20,18,18,Xwindow::White);
				}

			}
		}
	}
	if(pl1->get_blind()>0){
		win.fillRectangle(2*20,3*20,7*20,18*20,Xwindow::Yellow);
		win.fillRectangle(0,8*20,11*20,10*20,Xwindow::Yellow);
	}
	if(pl2->get_blind()>0){
		win.fillRectangle(16*20,3*20,7*20,18*20,Xwindow::Yellow);
		win.fillRectangle(14*20,8*20,11*20,10*20,Xwindow::Yellow);
	}
	win.fillRectangle(0,420,500,10,Xwindow::White);
	win.drawString(0,430,"Next:",Xwindow::Black);
	win.fillRectangle(11*20,0,60,500,Xwindow::White);

}


