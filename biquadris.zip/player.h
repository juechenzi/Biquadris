#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include "block.h"
#include "cell.h"
class Block;
class Cell;

class Player{
	std::string name;
	int level;
	int score;
	int speed;
	bool random;
	std::shared_ptr<Block> current;
	std::shared_ptr<Block> next;
	std::vector<std::vector<Cell>> theGrid;
	int level_four;
//	std::shared_ptr<Observer> textdisplay;
//	std::shared_ptr<Observer> graphicaldisplay;
	int done;
	void end();
	int bl;
public:
	std::string get_name();
	int get_score();
	int get_level();
	bool get_random();
	void change_random();
	Player(std::string name,int level = 0);	
	void start(std::shared_ptr<Block> t);
	int remove();
	void right();
	void left();
	void down(int d = 0);
	void up();
	void drop();
	void clockwise();
	void counterclockwise();
	void notify(int info);
	void heavy(int val);
	void blind();
	int get_blind();
	void levelup();
	void leveldown();
	void set_current(std::shared_ptr<Block> t);
	void set_next(std::shared_ptr<Block> t);
	void restart();
	bool check();
	void sdown();
	std::vector<std::string> print();
};

#endif
