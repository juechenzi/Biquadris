#ifndef __LEVEL2_H__
#define __LEVEL2_H__

#include "level.h"

class Level2: public Level {
	public:
		std::shared_ptr<Block> get_block(int a) override;
};

#endif



