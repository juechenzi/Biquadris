#include "oblock.h"

Oblock::Oblock(std::string type,int n) {
	this->level = n;
	this->type = type;
	this->location = Pos{0,0};
	this->relative.clear();
	this->from = nullptr;
	this->left_over = 4;
	for (int a = 0; a < 4;++a) {
		relative.push_back(Pos{0,0});
		relative.push_back(Pos{1,0});
		relative.push_back(Pos{0,1});
		relative.push_back(Pos{1,1});
	}
}

void Oblock::clockwise() { }

void Oblock::counterclockwise() { }




