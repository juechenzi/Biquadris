#ifndef __ZSBLOCK_H__
#define __ZSBLOCK_H__

#include "block.h"

class ZSblock: public Block {
	
	public:
	ZSblock(std::string type,int n);
	void clockwise() override;
	void counterclockwise() override;	
};

#endif

