#include "level2.h"

std::shared_ptr<Block> Level2::get_block(int b) {
	if(b < 0){
		srand(time(0));
	} else {
		srand(b);
	}
	int a = rand() % 7;
	std::shared_ptr<Block> tmp = nullptr;
	if (a == 0) {
		tmp = std::shared_ptr<Block> (new ZSblock{"Z",2});
	} else if (a == 6) {
		tmp = std::shared_ptr<Block> (new ZSblock{"S",2});
	} else if (a == 1) {
		tmp =  std::shared_ptr<Block> (new JTLblock("J",2));
	} else if (a == 2) {
		tmp = std::shared_ptr<Block> (new JTLblock("T",2));
	} else if (a == 3) {
		tmp = std::shared_ptr<Block> (new JTLblock("L",2));
	} else if (a == 4) {
		tmp =  std::shared_ptr<Block> (new Iblock("I",2));
	} else {
		tmp =  std::shared_ptr<Block> (new Oblock("O",2));
	}
	return tmp;
}

