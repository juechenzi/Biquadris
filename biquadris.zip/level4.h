#ifndef __LEVEL4_H__
#define __LEVEL4_H__

#include "level.h"

class Level4: public Level {
	public:
		std::shared_ptr<Block> get_block(int a) override;
};

#endif



