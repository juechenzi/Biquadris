#ifndef __IBLOCK_H__
#define __IBLOCK_H__
#include "block.h"
class Iblock: public Block {
	
	public:
		Iblock(std::string type,int n);
		void clockwise() override;
		void counterclockwise() override;	
};

#endif

