#include "level1.h"

std::shared_ptr<Block> Level1::get_block(int c) {
	if(c < 0){
		srand(time(0));
	} else {
		srand(c);
	}
	int a = rand() % 6;
	int b = rand() % 2;
	std::shared_ptr<Block> tmp = nullptr;
	if (a == 0 && b == 0) {
		tmp = std::shared_ptr<Block> (new ZSblock{"Z",1});
	} else if (a == 0) {
		tmp = std::shared_ptr<Block> (new ZSblock{"S",1});
	} else if (a == 1) {
		tmp =  std::shared_ptr<Block> (new JTLblock("J",1));
	} else if (a == 2) {
		tmp = std::shared_ptr<Block> (new JTLblock("T",1));
	} else if (a == 3) {
		tmp = std::shared_ptr<Block> (new JTLblock("L",1));
	} else if (a == 4) {
		tmp =  std::shared_ptr<Block> (new Iblock("I",1));
	} else {
		tmp =  std::shared_ptr<Block> (new Oblock("O",1));
	}
	return tmp;
}

