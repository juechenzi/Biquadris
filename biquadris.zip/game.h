#ifndef __GAME_H__
#define __GAME_H__

#include <vector>
#include <memory>
#include <fstream>
#include "observer.h"
#include "text.h"
#include "graph.h"
using namespace std;

class Player;
class Observer;
class Level;

class Game {
	std::shared_ptr<Player> player1;
	std::shared_ptr<Player> player2; 
	std::shared_ptr<Observer> textDisplay = nullptr;
	std::shared_ptr<Observer> graphicDisplay = nullptr;
	bool graphic = true;
	std::shared_ptr<vector<string>> seqOne = nullptr;
	std::shared_ptr<vector<string>> seqTwo = nullptr;
	std::string currOne;
	std::string currTwo;	
	bool turn = true;
	int highScore = 0;
	int random1 =0;
	int random2 =0;
	std::string noRandomOne;
	std::string noRandomTwo;
	std::shared_ptr<vector<string>> randomOne = nullptr;
	std::shared_ptr<vector<string>> randomTwo = nullptr;
	public: 
	Game(bool graphic, 
			std::shared_ptr<vector<string>> seqOne,
                        std::shared_ptr<vector<string>> seqTwo);
	void init(int level);
        void setInitBlock(bool graphic);	
	int readCmd();
	void specialAction();
	void restart(int level);
	void seed(int a);
	~Game();
};
#endif
