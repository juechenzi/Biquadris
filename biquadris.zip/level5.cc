#include "level5.h"

std::shared_ptr<Block> Level5::get_block(int b) {
//	std::cout<<"r is called"<<std::endl;
	srand(time(0));
	int a = rand() % 9;
	std::shared_ptr<Block> tmp = nullptr;
	if (a == 0) {
		tmp = std::shared_ptr<Block> (new ZSblock{"Z",5});
	} else if (a == 7) {
		tmp = std::shared_ptr<Block> (new ZSblock{"S",5});
	} else if (a == 1) {
		tmp =  std::shared_ptr<Block> (new JTLblock("J",5));
	} else if (a == 2) { 
		tmp = std::shared_ptr<Block> (new JTLblock("T",5));
	} else if (a == 3) {
		tmp = std::shared_ptr<Block> (new JTLblock("L",5));
	} else if (a == 4) {
		tmp =  std::shared_ptr<Block> (new Iblock("I",5));
	} else if (a == 5 ) {
		tmp =  std::shared_ptr<Block> (new Oblock("O",5));
	} else {
		tmp = std::shared_ptr<Block> (new Rblock(5));
	}
//	std::cout<<"r is ended"<<std::endl;
	return tmp;
}

