#ifndef __JTLBLOCK_H__
#define __JTLBLOCK_H__

#include "block.h"

class JTLblock: public Block {
	int cond;
	
	public:
		JTLblock(std::string type,int n);
		void set_rel();
		void clockwise() override;
		void counterclockwise() override;	

};

#endif

