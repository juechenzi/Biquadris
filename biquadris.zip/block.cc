#include "block.h"

//Block::Block(std::string type, Player* from, Pos location):type{type},location{location}{};
Block::~Block(){
	from = nullptr;
}
void Block::notify() {
	this->left_over -= 1;
//	std::cout<<"there are "<<left_over<<" left in block"<<std::endl;
	if (from && left_over == 0) {
		from->notify(level+1);
	}
}

void Block::set_from(Player* from) {
	this->from = from;
}

void Block::set_level(int l) {
	this->level = l;
}

void Block::set_pos(int x,int y) {
//	std::cout<<"set pos is called"<<std::endl;
	location.x = x;
	location.y = y;
}


void Block::down() {
	location.y -= 1;
}
std::string  Block::get_type() {
	return type;
}
void Block::right() {
	location.x += 1;
}
void Block::up(){
	location.y += 1;
}

void Block::left() {
	location.x -= 1;
}

std::vector<Pos> Block::get_pos() {
	std::vector<Pos> tmp;
	tmp.clear();
//	std::cout<<"the centre location is" <<location.x<<"  "<<location.y<<std::endl;
	for(auto &a :relative){
		tmp.push_back(Pos{a.x+location.x,a.y+location.y});
	}
	return tmp;
}

Pos Block::get_ori(){
	return location;
}
