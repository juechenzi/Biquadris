#ifndef __LEVEL_H__
#define __LEVEL_H__

#include <iostream>
#include <memory>
#include <ctime>
#include "jtlblock.h"
#include "zsblock.h"
#include "oblock.h"
#include "iblock.h"
#include "rblock.h"
class Level {
	public:
	virtual std::shared_ptr<Block> get_block(int a) = 0;
};

#endif
