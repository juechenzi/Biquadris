#ifndef __RBLOCK_H__
#define __RBLOCK_H__

#include "block.h"

class Rblock: public Block {	
	public:
		Rblock(int a);
		void clockwise() override;
		void counterclockwise() override;	
};

#endif

