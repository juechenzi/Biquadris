#ifndef __BLOCK_H__
#define __BLOCK_H__

#include <iostream>
#include "pos.h"
#include <string>
#include <sstream>
#include <vector>
#include "player.h"

class Player;

class Block {
	protected:
	std::string type;
	Pos location;
	std::vector<Pos> relative;
	Player* from;
	int left_over;
	int level;

	public:
//	Block(std::string type,Player* from ,Pos location);
	~Block();
	void notify();
	std::string get_type();
	void set_from(Player* from = nullptr);
	void set_pos(int x,int y);
	Pos get_ori();
	void set_level(int level);
	void up();
	void down();
	void right();
	void left();
	virtual void clockwise() = 0;
	virtual void counterclockwise() = 0;
	std::vector<Pos> get_pos();
};

#endif
