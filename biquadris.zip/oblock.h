#ifndef __OBLOCK_H__
#define __OBLOCK_H__

#include "block.h"

class Oblock: public Block {
	
	public:
		Oblock(std::string type,int n);
		void clockwise() override;
		void counterclockwise() override;	
};

#endif

