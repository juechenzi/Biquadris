#ifndef OBSERVER_H
#define OBSERVER_H
#include <iostream>
#include <memory>
#include <string>
#include "player.h"
class Player;
class Observer{
protected:
	std::shared_ptr<Player> pl1;
	std::shared_ptr<Player> pl2;
public:
	virtual void print() = 0;
};

#endif

