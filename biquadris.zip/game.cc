#include <iostream>
#include <fstream>
#include "game.h"
#include "player.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"
#include "level4.h"
#include "level5.h"
#include "zsblock.h"
#include "oblock.h"
#include "jtlblock.h"
#include "iblock.h"
#include "rblock.h"

using namespace std;
Game::Game(bool graphic, 
		shared_ptr<vector<string>> seqOne,
		shared_ptr<vector<string>> seqTwo):
	graphic{graphic}, seqOne{seqOne}, seqTwo{seqTwo} {	 
}

static string recognizeCmd(const string s) {
        if (s.substr(0, 3) == "lef") {
                return "left";
        }
        if (s.substr(0, 2) == "ri") {
                return "right";
        }
        if (s.substr(0, 2) == "do") {
                return "down";
        }
        if (s.substr(0, 1) == "c") {
                if (s.substr(0, 2) == "cl") {
                        return "clockwise";
                } else if (s.substr(0, 2) == "co") {
                        return "counterclockwise";
                } else {
                        return "unrecognized command";
                }
        }
        if (s.substr(0, 2) == "dr") {
                return "drop";
        }
        if (s.substr(0, 5) == "level") {
                if (s.substr(0, 6) == "levelu") {
                        return "levelup";
                } else if (s.substr(0, 6) == "leveld") {
                        return "leveldown";
                } else {
                        return "unrecognized command";
                }
        }
        if (s.substr(0, 2) == "no") {
                return "norandom";
        }
        if (s.substr(0, 2) == "ra") {
                return "random";
        }
        if (s.substr(0, 2) == "se") {
                return "sequence";
        } 
	if (s == "I" || s == "J" || s == "T" || s == "L" || s == "O"  || s == "Z" || s == "S"|| s == "R"){
		return s;
	}
        return "unrecognized command";
}

static string recognizeSpecial(const string s) {
	if (s.substr(0, 1) == "b") {
		return "blind";
	}
	if (s.substr(0, 1) == "h") {
		return "heavy";
	}
	if (s.substr(0, 1) == "f") {
		return "force";
	}
	return "unrecognized command";
} 
static void prefixCommand(const string s, string& cmd, int& multi) {
	string pre;
        int length = s.length();
        for (int i = 0; length; i++) {
                if (s[i] < '0' || s[i] > '9') {
                        pre = s.substr(0, i);
                        if (pre == "" || pre == "0" || pre == "1") {
                                multi = 1;
                        } else {
                                multi = stoi(pre);
                        }
                        cmd = s.substr(i);
			cmd = recognizeCmd(cmd);
                        break;
                }
        }
}

static std::shared_ptr<Block> chooseBlock(const string s, const int level) {
	if (s == "I") {
		return std::shared_ptr<Block> (new Iblock{"I", level});
	} 
	if (s == "O") {
		return std::shared_ptr<Block> (new Oblock{"O", level});
	}
	if (s == "J") {
		return std::shared_ptr<Block> (new JTLblock{"J", level});
	}
	if (s == "T") {
		return std::shared_ptr<Block> (new JTLblock("T", level));
	}
	if (s == "L") {
		return std::shared_ptr<Block> (new JTLblock("L", level));
	}
	if (s == "Z") {
		return std::shared_ptr<Block> (new ZSblock{"Z", level});
	}
	if (s == "S") {
		return std::shared_ptr<Block> (new ZSblock{"S", level});
	}
	if (s == "R"){
		return std::shared_ptr<Block> (new Rblock(level));
	}
	return nullptr;
}

void Game::init(int level) {
	string input;
	cout << "Please enter Player1 name: ";
        cin >> input;
	player1 = std::shared_ptr<Player> (new Player{input, level});
	if (level == 0) {
		currOne = seqOne->front();
	}
	cout << "Please enter Player2 name: ";
	cin >> input;
	player2 = std::shared_ptr<Player> (new Player{input, level});
	if (level == 0) {
		currTwo = seqTwo->front();
	}
}

void Game::setInitBlock(bool graphic) {
	cout << endl << "Game Start!" << endl;
	if (player1->get_level() == 1) {
		shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
		player1->set_next(level->get_block(random1));
	} else if (player1->get_level() == 2) {
		shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
                player1->set_next(level->get_block(random1));
	} else if (player1->get_level() == 3) {
		shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
		player1->set_next(level->get_block(random1));
	} else if (player1->get_level() == 4) {
		shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
		player1->set_next(level->get_block(random1));
	} else if (player1->get_level() == 5) {
		shared_ptr<Level5> level = shared_ptr<Level5> (new Level5());
		player1->set_next(level->get_block(random1));
	} else {
		player1->set_next(chooseBlock(currOne, 0));
		string curr = seqOne->front();
		seqOne->erase(seqOne->begin());
		seqOne->emplace_back(curr);
		currOne = seqOne->front();
	}
	if (player2->get_level() == 1) {
                shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
                player2->set_next(level->get_block(random1));
        } else if (player2->get_level() == 2) {
                shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
                player2->set_next(level->get_block(random1));
        } else if (player2->get_level() == 3) {
                shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
                player2->set_next(level->get_block(random1));
        } else if (player2->get_level() == 4) {
                shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
                player2->set_next(level->get_block(random1));
        } else if (player2->get_level() == 5) {
                shared_ptr<Level5> level = shared_ptr<Level5> (new Level5());
                player2->set_next(level->get_block(random1));
        } else {
                player2->set_next(chooseBlock(currTwo, 0));
                string curr = seqTwo->front();
                seqTwo->erase(seqTwo->begin());
                seqTwo->emplace_back(curr);
                currTwo = seqTwo->front();
        }
	textDisplay = std::shared_ptr<Text> (new Text(player1,player2));
	if(graphic){
		graphicDisplay = std::shared_ptr<Graph> (new Graph(player1,player2));
	} else {
		graphicDisplay = nullptr;
	}
	random1++;
	random2++;
//	textDisplay->print();
//	std::cout<<"Printing should be before this line"<<std::endl;
}

int Game::readCmd() {
//	textDisplay->print();
	string cmd;
	shared_ptr<Player> player;
	if (this->turn) {
		player = player1;
		cout << "Player1's turn: " << endl;
	} else {
		player = player2;
		cout << "Player2's turn: " << endl;
	}	
	try { 
		if (player->get_level() == 1) {
			if(this->turn){
				shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
				player->start(level->get_block(random1));
				++random1;
			} else {
				shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
				player->start(level->get_block(random2));
				++random2;

			}
		} else if (player->get_level() == 2) {
			if(this->turn){
				shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
				player->start(level->get_block(random1));
				++random1;
			} else {
				shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
				player->start(level->get_block(random2));
				random2++;
			}
		} else if (player->get_level() == 3) {
			if (player->get_random()) {
				if(this->turn){
					shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
					player->start(level->get_block(random1));
					++random1;
				} else {
					shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
					player->start(level->get_block(random2));
					++random2;
				}
			} else {
				if (this->turn) {
                                	player1->start(chooseBlock(noRandomOne, 3));
                                	string curr = randomOne->front();
                                	randomOne->erase(randomOne->begin());
                                	randomOne->emplace_back(curr);
                                	noRandomOne = randomOne->front();
                        	} else {
                                	player2->start(chooseBlock(noRandomTwo, 3));
                                	string curr = randomTwo->front();
                                	randomTwo->erase(randomTwo->begin());
                                	randomTwo->emplace_back(curr);
                                	noRandomTwo = randomTwo->front();
                       		}
			}
		} else if (player->get_level() == 4) {
			if (player->get_random() == true) {
				if(this->turn){
     					shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
	      				player->start(level->get_block(random1));
					++random1;
				} else {
      					shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
	      				player->start(level->get_block(random2));
					++random2;
				}
                        } else {
                                if (this->turn) {
                                        player1->start(chooseBlock(noRandomOne, 4));
                                        string curr = randomOne->front();
                                        randomOne->erase(randomOne->begin());
                                        randomOne->emplace_back(curr);
                                        noRandomOne = randomOne->front();
                                } else {
                                        player2->start(chooseBlock(noRandomTwo, 4));
                                        string curr = randomTwo->front();
                                        randomTwo->erase(randomTwo->begin());
                                        randomTwo->emplace_back(curr);
                                        noRandomTwo = randomTwo->front();
                                }
                        }
		} else if(player->get_level() == 5){
			shared_ptr<Level5> level = shared_ptr<Level5> (new Level5());
	      		player->start(level->get_block(random1));
		} else {
			if (this->turn) {
				player1->start(chooseBlock(currOne, 0));
				string curr = seqOne->front();
				seqOne->erase(seqOne->begin());
                		seqOne->emplace_back(curr);
                		currOne = seqOne->front();
			} else {
			 	player2->start(chooseBlock(currTwo, 0));
				string curr = seqTwo->front();
                		seqTwo->erase(seqTwo->begin());
                		seqTwo->emplace_back(curr);
                		currTwo = seqTwo->front();
			}	
		}
	} catch (string result) {
		textDisplay->print();
		int p1 = player1->get_score();
		int p2 = player2->get_score();
		if (p1 > p2) {
			cout << player1->get_name() << " " << result << endl;
		} else if (p1 < p2) {
			cout << player2->get_name() << " " << result << endl;
		} else {
			cout << "Tie!" << endl;
		}
		if (highScore == 0) {
			highScore = p1 > p2 ? p1 : p2;
		}
		cout << "High score: " << highScore << endl;

		return -1;
	}
	textDisplay->print();
	if(graphicDisplay){
		graphicDisplay->print();
	}
	cin >> cmd;
	string actualCmd;
	int multi;
	prefixCommand(cmd, actualCmd, multi);
	while (actualCmd != "drop") {
		if (actualCmd == "unrecognized command") {
			cin >> cmd;
			prefixCommand(cmd, actualCmd, multi);
			continue;
		} else if (actualCmd == "J" || actualCmd == "T" || actualCmd == "L" || actualCmd == "O" 
				|| actualCmd == "I" || actualCmd == "Z" || actualCmd == "S" || actualCmd == "R") {
			cout << "change block is called" << endl;
			player->set_current(chooseBlock(cmd, player->get_level()));
		} else if (actualCmd == "random") {
			if (player->get_level() < 3) { 
				cout << "level too low to change randomness" << endl;
			} else {
				if (player->get_random() == false) {
					player->change_random();
				}
			}
		} else if (actualCmd == "norandom") {
			if (player->get_level() < 3) {
				cout << "level too low to change randomness" << endl;
			} else {
				cout << "Enter the file name you wish to get block from: " << endl;
				cin >> cmd;
				ifstream file{cmd};
				if (!file.fail()) {
					if (player->get_random() == true) {
						player->change_random();
					}
					if (this->turn) {
						if (randomOne) {
							randomOne->clear();
						}
						randomOne = std::shared_ptr<vector<string>> (new vector<string>);
						string block;
						while (file >> block) {
							randomOne->emplace_back(block);
						}
						noRandomOne = randomOne->front();
					} else {
						if (randomTwo) {
							randomTwo->clear();
						}
						randomTwo = std::shared_ptr<vector<string>> (new vector<string>);
						string block;
						while (file >> block) {
							randomTwo->emplace_back(block);
						}
						noRandomTwo = randomTwo->front();
					}
				} else {
					cout << "File not found, remain random status" << endl;
				}
			}
		} else { 
			for (int i = 0; i < multi; i++) {
				if (actualCmd == "left") {
					player->left();
				} else if (actualCmd == "right") {
					player->right();
				} else if (actualCmd == "down") {
					player->down();
				} else if (actualCmd == "clockwise") {
					player->clockwise();
				} else if (actualCmd == "counterclockwise") {
					player->counterclockwise();
				} else if (actualCmd == "levelup") {
					player->levelup();
				} else if (actualCmd == "leveldown") {
					player->leveldown();
				} 
			}
			if (actualCmd != "levelup" && actualCmd != "leveldown") {
//				std::cout<<"Game is calling sdown"<<std::endl;
				player->sdown();
			}
		}
		textDisplay->print();
		if(graphicDisplay){
			graphicDisplay->print();
		}
		cin >> cmd;
		prefixCommand(cmd, actualCmd, multi);
	} 
	for (int i = 0; i < multi - 1; i++) {
		player->drop();
		try {
                if (player->get_level() == 1) {
			if(this->turn){
	               	        shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
                        	player->start(level->get_block(random1));
				random1++;
			} else {			
	               	        shared_ptr<Level1> level = shared_ptr<Level1> (new Level1());
                        	player->start(level->get_block(random2));
				random2++;
			}
                } else if (player->get_level() == 2) {
			if(this->turn){
	                        shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
        	                player->start(level->get_block(random1));
				++random1;
			} else {
			        shared_ptr<Level2> level = shared_ptr<Level2> (new Level2());
        	                player->start(level->get_block(random2));
				++random2;			
			}
                } else if (player->get_level() == 3) {
                         if (player->get_random()) {
				 if(this->turn){
	                                shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
        	                        player->start(level->get_block(random1));
					++random1;
				 } else {
	                                shared_ptr<Level3> level = shared_ptr<Level3> (new Level3());
        	                        player->start(level->get_block(random2));
					++random2;
				 }
                        } else {
                                if (this->turn) {
                                        player1->start(chooseBlock(noRandomOne, 3));
                                        string curr = randomOne->front();
                                        randomOne->erase(randomOne->begin());
                                        randomOne->emplace_back(curr);
                                        noRandomOne = randomOne->front();
                                } else {
                                        player2->start(chooseBlock(noRandomTwo, 3));
                                        string curr = randomTwo->front();
                                        randomTwo->erase(randomTwo->begin());
                                        randomTwo->emplace_back(curr);
                                        noRandomTwo = randomTwo->front();
                                }
                        }
                } else if (player->get_level() == 4) {
                         if (player->get_random()) {
				 if(this->turn){
	                               shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
        	                       player->start(level->get_block(random1));
				       random1++;
				 } else {
	                               shared_ptr<Level4> level = shared_ptr<Level4> (new Level4());
        	                       player->start(level->get_block(random2));
				       random2++;
				 }
                        } else {
                                if (this->turn) {
                                        player1->start(chooseBlock(noRandomOne, 4));
                                        string curr = randomOne->front();
                                        randomOne->erase(randomOne->begin());
                                        randomOne->emplace_back(curr);
                                        noRandomOne = randomOne->front();
                                } else {
                                        player2->start(chooseBlock(noRandomTwo, 4));
                                        string curr = randomTwo->front();
                                        randomTwo->erase(randomTwo->begin());
                                        randomTwo->emplace_back(curr);
                                        noRandomTwo = randomTwo->front();
                                }
                        }
                } else if(player->get_level() == 5) {
                         if (player->get_random()) {
				 if(this->turn){
	                               shared_ptr<Level5> level = shared_ptr<Level5> (new Level5());
        	                       player->start(level->get_block(random1));
				 } else {
	                               shared_ptr<Level5> level = shared_ptr<Level5> (new Level5());
        	                       player->start(level->get_block(random2));
				 }
                        } else {
                                if (this->turn) {
                                        player1->start(chooseBlock(noRandomOne, 5));
                                        string curr = randomOne->front();
                                        randomOne->erase(randomOne->begin());
                                        randomOne->emplace_back(curr);
                                        noRandomOne = randomOne->front();
                                } else {
                                        player2->start(chooseBlock(noRandomTwo, 5));
                                        string curr = randomTwo->front();
                                        randomTwo->erase(randomTwo->begin());
                                        randomTwo->emplace_back(curr);
                                        noRandomTwo = randomTwo->front();
                                }
                        }

		} else {
                        if (this->turn) {
                                player1->start(chooseBlock(currOne, 0));
                                string curr = seqOne->front();
                                seqOne->erase(seqOne->begin());
                                seqOne->emplace_back(curr);
                                currOne = seqOne->front();
                        } else {
                                player2->start(chooseBlock(currTwo, 0));
                                string curr = seqTwo->front();
                                seqTwo->erase(seqTwo->begin());
                                seqTwo->emplace_back(curr);
                                currTwo = seqTwo->front();
                        }
                }
        } catch (string result) {
		textDisplay->print();
		if(graphicDisplay){
			graphicDisplay->print();
		}
                int p1 = player1->get_score();
                int p2 = player2->get_score();
                if (p1 > p2) {
                        cout << player1->get_name() << " " << result << endl;
                } else if (p1 < p2) {
                        cout << player2->get_name() << " " << result << endl;
                } else {
                        cout << "Tie!" << endl;
                }
                if (highScore == 0) {
                        highScore = p1 > p2 ? p1 : p2;
                }
		cout << "High score: " << highScore << endl;
                return -1;
        }
	}
	player->drop();
	cout<<"display is called"<<std::endl;
	textDisplay->print();
	if(graphicDisplay){
		graphicDisplay->print();
	}
	if (highScore != 0 && highScore <= player->get_score()) {
		highScore = player->get_score();
	}
	if (turn) {
		turn = false;
	} else {
		turn = true;
	}

	return player->remove();
}

void Game::specialAction() {
	std::shared_ptr<Player> player;
	if (turn) {
		player = player1;
	} else {
		player = player2;
	}
	cout << "Please choose the following three special actions: " << endl;
	cout << "heavy  blind  force" << endl;
	string input;
	cin >> input; 
	string actualCmd = recognizeSpecial(input);
	while (actualCmd == "unrecognized command") {
		cout << "unrecognized command, please try again: ";
		cin >> input;
		cout << endl;
		actualCmd = recognizeSpecial(input);
	} 
	if (actualCmd == "heavy") {
		player->heavy(1);
	} else if (actualCmd == "blind") {
		if (turn) {
			player1->blind();
		} else {
			player2->blind();
		}
	} else if (actualCmd == "force") { 
		cout << "choose the next block for your opponent: ";
		cin >> input;
		while (input != "S" && input != "Z" && input != "J" 
				&& input != "T" && input != "L" && input != "O" 
				&& input != "I" && input != "R") {
			cout << "unrecognized block, please try again: ";
			cin >> input;
			cout << endl;
		}
		int currLevel = player->get_level();
		player->set_next(chooseBlock(input, currLevel));
	}	
}

void Game::restart(int level) {
	turn = true;
	player1->restart();
	player2->restart();
	textDisplay = std::shared_ptr<Text> (new Text(player1, player2));
	init(level);
}

void Game::seed(int a){
//	cout<<"set seed to be"<<a<<endl;
	random1 = a;
	random2 = a;
}

Game::~Game() { }
