#include "player.h"
Player::Player(std::string name,int level):name{name},level{level}{
	done = -1;
	score = 0;
	speed = 0;
	random = true;
	theGrid.clear();
	current = nullptr;
	next = nullptr;
	level_four = 0;
	bl = 0;
	if(level != 0){
		random = true;
	}
	if(level >= 3){
		speed = 1;
	}
}


void Player::notify(int info){
	score += info;
}

bool Player::get_random() {
	return random;
}

void Player::change_random() {
	if (random) {
		random = false;
	} else {
		random = true;
	}
}
void Player::right(){
	try{
		current->right();
		if(check()){
			throw 5;
		}
	}catch(int n){
		current->left();
	}
}

void Player::left(){
	int a = 5;
	try{
		current->left();
		if(check()){
			throw a;
		}
	}	catch(int n){
		current->right();
	}
}

void Player::down(int d){
	int a = 5;
	try{
		current->down();
		if(check()){
			throw a;
		}
	}catch(int n){
		current->up();
		if(d != 0){
			throw a;
		}
	}
//	std::cout<<"Down is called"<<std::endl;
}
void Player::sdown(){
//	std::cout<<"speed is "<<speed<<std::endl;
	for(int a = 0 ;a < speed;++a){
		std::cout<<a<<std::endl;
		try{
		this->down(1);
		} catch(int b){
//			current->up();
			break;
		}
	}
}

void Player::start(std::shared_ptr<Block> t){
//	std::cout<<"Start is called"<<std::endl;
	done = -1;
	std::string tmp = "Win!";
	current = next;
	next = t;
	if(t){
		t->set_from(this);
	}
	if(current){
//		std::cout<<"this should be displayed"<<std::endl;
		current->set_pos(0,14);
	}
	if(check()){
//		exit(1);
		current = nullptr;
		throw tmp;
	}
}

void Player::end(){
//	std::cout<<"End is called"<<std::endl;
	done = true;
	std::vector<Pos> tmp = current->get_pos();
	for(auto &a : tmp){
		while(a.y >= theGrid.size()){
			std::vector<Cell> temp(11,Cell());
			theGrid.push_back(temp);
		}
		theGrid[a.y][a.x].set_type(current->get_type());
		theGrid[a.y][a.x].set_from(current);
	}
	current = nullptr;
	bool cond = true;
	done = 0;
//	std::cout<<"End is good so far"<<std::endl;
	for(int a = 0; a < theGrid.size() ; ++a){
//		std::cout<<"Checking: line "<<a<<std::endl;
		for(auto &b : theGrid[a]){
//			std::cout<<"the cell is in"<<b.get_type()<<"|"<<std::endl;
			if(b.get_type() == " "){
				cond = false;
				break;
			}
		}
		if(cond){
//			std::cout<<"line "<<a<<"is full"<<std::endl;
			done++;
			for(auto &b : theGrid[a]){
				b.notify();
			}
			theGrid.erase(theGrid.begin()+a);
			--a;
		}
		cond = true;
	}
	if(done != 0){
		score += (done + level) * (done + level);
	} else if(level == 4){
		++level_four;
	}
	if(level_four >= 5){
		bool spe = true;
		for(auto & a : theGrid){
			if(a[5].get_type() == " "){
				a[5].set_type("*");
				spe = false;
				break;
			}
		}
		if(spe){
			std::vector<Cell> a(11,Cell());
			a[5].set_type("*");
			theGrid.push_back(a);
		}
		level_four = 0;	
	}
	if(level >= 3){
		speed = 1;
	} else {
		speed = 0;
	}
	bl =0;
//	std::cout<<"End is finished"<<std::endl;

}

int Player::remove(){
	return done;
}

void Player::drop(){
	while(true){
		try{
			this->down(1);
		} catch(int a){
//			std::cout<<"This is the last move"<<std::endl;
			break;
		}
	}
//	std::cout<<"End is called after this"<<std::endl;
	this->end();
//	std::cout<<"Eric is correct"<<std::endl;
}

void Player::clockwise(){
	try{
		current->clockwise();
		if(check()){
			throw 5;
		}
	}catch(int n){
		current->counterclockwise();
	}
}

void Player::counterclockwise(){
//	std::cout<<"count is called"<<std::endl;
	try{
		current->counterclockwise();
//		std::cout<<"counterclockwise is called"<<std::endl;
		if(check()){
			throw 5;
		}
	}  catch(int n){
		current->clockwise();
	}
}



void Player::heavy(int val){
	speed += val;
}
/*
void Player::blind(){
	this->testdisplay.blind();
}
*/
void Player::levelup(){
	level++;
	if(level > 5){
		level = 5;
	}
	if(level == 3){
		speed = 1;
	} else if(level == 4){
		level_four = 0;
	}
}

void Player::leveldown(){
	level--;
	if(level < 0){
		level = 0;
	}
	if(level == 2){
		speed = 0;
	}
}

void Player::set_next(std::shared_ptr<Block> t){
//	std::cout<<"set next is called"<<std::endl;
	next = t;
	if(next){
		next->set_from(this);
	}
}

void Player::set_current(std::shared_ptr<Block> t){
//	std::cout<<"set current is called"<<std::endl;
	if(current){
		t->set_pos(current->get_ori().x,current->get_ori().y);
	} else {
		t->set_pos(4,14);
	}
	current = t;
	if(current){
		current->set_from(this);
	}
}

void Player::restart(){
	theGrid.clear();
	current = nullptr;
	next = nullptr;
	done = -1;
//	textdisplay = std::shared_ptr<Observer> (new Text(this));
//	graphicaldisplay = std::shared_ptr<Observer> (new Graph(this));
	score = 0;
	level = 0;
	speed = 0;
}

bool Player::check(){
//	std::cout<<"Check is called"<<std::endl;
	if(current){
		std::vector<Pos> tmp = current->get_pos();
		int a = theGrid.size();
		for(auto &t :tmp){
//			std::cout<<"t.x: "<<t.x<<"t.y= "<<t.y<<std::endl;
			if(t.x > 10 || t.x < 0 || t.y < 0|| t.y > 17){
//				std::cout<<"This should be displayed when check is called"<<std::endl;
				return true;
			} else if(t.y < a){
//				std::cout<<"the corresponding space is: "<<theGrid[t.y][t.x].get_type()<<"|"<<std::endl; 
				if(theGrid[t.y][t.x].get_type() != " ") return true;
			}
		}
	}
	return false;

}

std::vector<std::string> Player::print(){
//	std::cout<<"The print in the player is called"<<std::endl;
	std::string tmp = "";
	int a = 0;
	std::vector<std::string> con;
	tmp.resize(11,' ');
	for(int c = 0;c < 3;++c){
		con.push_back(tmp);
	}
	tmp = "";
	tmp.resize(11,'-');
	con.push_back(tmp);

	if(next){
		std::vector<Pos> posi = next->get_pos();
		std::string typ = next->get_type();
		for(auto &b : posi){
			con[b.y][b.x+3] = typ[0];
		}
	}

	while(a < theGrid.size()){
		tmp = "";
		for(auto &b : theGrid[a]){
			tmp += b.get_type();
		}
		con.push_back(tmp);
		++a;
	}
	tmp ="";
//	std::cout<<"print at here is good"<<std::endl;
	tmp.resize(11,' ');
	for(int b = a;b < 18;++b){
		con.push_back(tmp);
	}
	if(current){
		std::vector<Pos> posi = current->get_pos();
		std::string typ = current->get_type();
		for(auto &b : posi){
//			std::cout<<"b is:"<<b.y<<" "<<b.x<<std::endl;
			con[b.y+4][b.x] = typ[0];
		}
	}
//	std::cout<<"Player is good again"<<std::endl;
	return con;
}


std::string Player::get_name(){
	return name;
}

int Player::get_score(){
	return score;
}

int Player::get_level(){
	return level;
}

void Player::blind(){
	bl++;
}

int Player::get_blind(){
	return bl;
}


