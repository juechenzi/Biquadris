#ifndef GRAPH_H
#define GRAPH_H
#include "observer.h"
#include "window.h"

class Graph: public Observer{
	Xwindow win;
	int size;
public:
	Graph(std::shared_ptr<Player> ply1, std::shared_ptr<Player> ply2);
//	void blind(int a)override;
	void print() override;
};

#endif
