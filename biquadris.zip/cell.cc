#include "cell.h"

Cell::Cell(std::string type,std::shared_ptr<Block> from):type{type},from{from}{}
Cell::~Cell(){
	from = nullptr;
}

std::string Cell::get_type() { 
	return type;
}

void Cell::notify(){
	if (from) { 
		from->notify();
	}
}


void Cell::set_type(std::string t){
	type = t;
}

void Cell::set_from(std::shared_ptr<Block> t){
	from = t;
}
