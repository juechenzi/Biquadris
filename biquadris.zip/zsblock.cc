#include "zsblock.h"

ZSblock::ZSblock(std::string type,int n){
	this->level = n;
	this->type = type;
	this->location = Pos{0,0};
	this->relative.clear();
	this->from = nullptr;
	this->left_over = 4;
	if (this->type == "S") { 
		this->relative.push_back(Pos{0,0});
		this->relative.push_back(Pos{1,0});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{2,1});
	} else {
		this->relative.push_back(Pos{1,0});
		this->relative.push_back(Pos{0,1});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{2,0});
	}
}


void ZSblock::clockwise() {
	bool cond = false;
	for (auto &a : relative) {
		if (a.x == 0 && a.y == 0) {
			cond = true;
			break;
		}
	}
	if (cond && this->type == "S") {
		this->relative.clear();
		this->relative.push_back(Pos{0,1});
		this->relative.push_back(Pos{0,2});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{1,0});
	} else if (cond) {
		this->relative.clear();
		this->relative.push_back(Pos{0,1});
		this->relative.push_back(Pos{1,0});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{2,0});
	} else if (this->type == "S") {
		this->relative.clear();
		this->relative.push_back(Pos{0,0});
		this->relative.push_back(Pos{1,0});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{2,1});
	} else {
		this->relative.clear();
		this->relative.push_back(Pos{0,0});
		this->relative.push_back(Pos{0,1});
		this->relative.push_back(Pos{1,1});
		this->relative.push_back(Pos{1,2});
	}
}


void ZSblock::counterclockwise() {
	this->clockwise();
}
