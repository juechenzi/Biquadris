#include "text.h"

Text::Text(std::shared_ptr<Player> ply1,std::shared_ptr<Player> ply2){
	this->pl1=ply1;
	this->pl2=ply2;
}


void Text::print(){
//	std::cout<<"Pos1"<<std::endl;
	std::vector<std::string> tmp;
	tmp.clear();
	std::string tmp1 = "Level:  ";
	std::string tmp2;
	tmp2 = tmp1 + std::to_string(pl1->get_level());
	tmp2.resize(15,' ');
	tmp2 += tmp1;
	tmp2 += std::to_string(pl2->get_level());
	tmp2.resize(26,' ');
	tmp.push_back(tmp2);
	tmp1 = "Score:  ";
	tmp2 = tmp1 + std::to_string(pl1->get_score());
	tmp2.resize(15,' ');
	tmp2 += tmp1;
	tmp2 += std::to_string(pl2->get_score());
	tmp2.resize(26,' ');
	tmp.push_back(tmp2);
	tmp2 = "";
	tmp2.resize(26,'-');
	tmp.push_back(tmp2);
//	std::cout<<"Pos2"<<std::endl;
	std::vector<std::string> set1 = pl1->print();
	std::vector<std::string> set2 = pl2->print();
	if(pl1->get_blind() >0){
		for(int a = 4; a <set1.size();++a){
			if(a < 6 || a > 15){	
				for(int b = 2; b < 9;++b){
					set1[a][b] = '?';
				}
			} else {
				std::string blin ="";
				blin.resize(11,'?');
				set1[a] =blin;
			}	
		}
	}
	if(pl2->get_blind() >0){
		for(int a = 4; a <set2.size();++a){
			if(a < 6 || a > 15){	
				for(int b = 2; b < 9;++b){
					set2[a][b] = '?';
				}
			} else {
				set2[a] ="";
				set2[a].resize(11,'?');
			}
		}
	}
	for(int a = set1.size() -1; a >= 0 ;--a){
		tmp2 = set1[a];
		tmp2.resize(15,' ');
		tmp2 += set2[a];
		tmp2.resize(26,' ');
		tmp.push_back(tmp2);
	}
	for(auto a:tmp){
		std::cout<<a<<std::endl;
	}
	tmp2 ="";
	tmp2.resize(26,'-');
	std::cout<<tmp2<<std::endl;
}	
