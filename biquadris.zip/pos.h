#ifndef __POS_H__
#define __POS_H__

#include <iostream>

struct Pos {
	int x;
	int y;
};

#endif
