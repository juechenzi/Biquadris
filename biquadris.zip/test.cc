#include <iostream>
#include <cstdlib>
#include <ctime>

int main(){
	srand(0);
	int a = rand() % 6;
	std::cout<<a<<std::endl;
	srand(time(0));
	a = rand() % 6;
	std::cout<<a<<std::endl;
}

