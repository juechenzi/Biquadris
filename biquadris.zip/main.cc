#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <memory>
#include "player.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"
#include "level4.h"
#include "game.h"

using namespace std;

int main(int argc, char* argv[]) {
        //shared_ptr<Game> game(new Game());
	// determine initialization based on arugments 
	string args;
	bool graphic = true;
	int startLevel = 0;
	shared_ptr<vector<string>> seqOne = 
		shared_ptr<vector<string>> (new vector<string>);
	shared_ptr<vector<string>> seqTwo =
                shared_ptr<vector<string>> (new vector<string>);
	seqOne->clear();
	seqTwo->clear();
	int seed = 0;
	for (int i = 1; i < argc; i++) {
		args = argv[i];
		if (args == "-text") {
			graphic = false;
		} 
		if (args == "-scriptfile1") {
			if (i == argc - 1) {
				cerr << "Incorrect argument format" << endl;
				exit(1);
			}
			args = argv[i+1];
			ifstream file{args};
			if(!file.fail()) {
				string block;
				while (file >> block) {
					seqOne->emplace_back(block);
				}
			} else {
				cerr << "file for scriptfile1 not found" << endl;
				exit(1);
			}
		}
		if (args == "-scriptfile2") {
			if (i == argc - 1) {
				cerr << "Incorrect argument format" << endl;
				exit(1);
			}
			args = argv[i+1];
			ifstream file{args};
			if(!file.fail()) {
				string block;
				while (file >> block) {
					seqTwo->emplace_back(block);
				}
			} else {
				cerr << "file for scriptfile2 not found" << endl;
				exit(1);
			}
		}
		if (args == "-startlevel") { 
		       if (i == argc - 1) {
			       cerr << "Incorrect argument format" << endl;
			       exit(1);
		       }
		       args = argv[i+1];
		       istringstream iss{args};
		       if (iss >> startLevel) {
			       if (startLevel < 0 || startLevel > 5) {
				       cerr << "Invalid input for start level" << endl;
				       exit(1);
			       }
		       } else {
			       cerr << "Needs an integer for start level" << endl;
			       exit(1);
		       }
		}
		if (args == "-seed") {
			if( i == argc -1) {
				cerr << "Incorrect argument format" <<endl;
				exit(1);
			}
			args = argv[i+1];
			seed = stoi(args);
		}
		if (args == "-random"){
			seed = -1;
		}
	}
	if (seqOne->empty()) {
		ifstream file{"sequence1.txt"};
                        if(!file.fail()) {
                                string block;
                                while (file >> block) {
                                        seqOne->emplace_back(block);
                                }
                        } else {
                                cerr << "block file for player1 not found" << endl;
                                exit(1);
                        }
	}
	if (seqTwo->empty()) {
		ifstream file{"sequence2.txt"};
                        if(!file.fail()) {
                                string block;
                                while (file >> block) {
                                        seqTwo->emplace_back(block);
                                }
                        } else {
                                cerr << "block file for player2 not found" << endl;
                                exit(1);
                        }
	}
	shared_ptr<Game> game(new Game(graphic,seqOne, seqTwo));
		game->seed(seed);
	game->init(startLevel); // game initialization
        string input;
        while (true) {
                game->setInitBlock(graphic); // set initial blocks for both players
                // starting to accept commands
                while (true) {
			if(seed == -1){
				game->seed(-1);
			}
                        int clear = game->readCmd();
                        if (clear >= 2) {
                                game->specialAction();
                        }
			if (clear == -1) {
                                cout << "restart game? Y/N" << endl;
                                cin >> input;
				if (cin.eof()) {
                                        cout << "Game over." << endl;
                                        return 0;
                                }
                                while (input != "Y" && input != "N") {
                                        cout << "Invalid input, try agin." << endl;
                                        cin >> input;
					if (cin.eof()) {
                                        	cout << "Game over." << endl;
                                        	return 0;
                               		}
                                }
                                if (input == "Y") {
                                        game->restart(startLevel);
                                        game->setInitBlock(graphic);
					continue;
                                } else {
                                        cout << "Game over." << endl;
					return 0;
                                }
                        }

                }
        }
}

