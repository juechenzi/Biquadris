#ifndef __CELL_H__
#define __CELL_H__

#include <iostream>
#include <memory>
#include "block.h"

class Block;

class Cell {
	std::string type;
	std::shared_ptr<Block> from;
public:
	Cell(std::string type = " ", std::shared_ptr<Block> from = nullptr);
	void set_type(std::string t);
	void set_from(std::shared_ptr<Block> t);
	std::string get_type();
	void notify();
	~Cell();
};

#endif
